class TreeSettings:
    def __init__(self):
        self.print_data: bool = True
        self.print_data_with_accessing_field: bool = False
        self.accessing_field = 1
